from ifood_class import Isimov

bot = Isimov('rodrigovanzelotti@gmail.com')

bot.pedido_padrao('padrão', 1)