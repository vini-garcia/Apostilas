# MetaTrader5 Project
### Gathering info and storing using Parquet, just the beggining
